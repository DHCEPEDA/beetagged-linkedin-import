/**
 * BeeTagged Main Entry Point
 * This file serves as the main entry point for Replit
 */
require('./bee-tagged-server.js');